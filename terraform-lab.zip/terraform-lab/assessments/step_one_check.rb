# method description
def check(handles, maximum_score)

  # Service handle initialization
  bigquery = handles['project_0.BigqueryV2']
 
  # Assessment score and status checker hash variable
  ret_hash = { :done => false, :score => 0, :message => "", :student_message => "" }

  # Assessment specific variable
  job_state = 'DONE'
  
  desired_dataset_id = 'terraform_dataset'
  desired_table_id = 'employee'
 source_url = 'gs://' +bigquery.project+ '/hello.csv'
 avail_data = false
 avail_format = false
 avail_state = false


  # API call to list available BQ jobs
  jobs = bigquery.list_jobs(all_users:true)&.jobs || []

  # Iterate over BQ job resources
  jobs.each do |job|
    if !(job&.status&.error_result) && job&.status&.state==job_state
    avail_state = true 
   end
# API call to get BQ job
job_details = bigquery.get_job(job.job_reference.job_id)
if job_details.configuration.load.destination_table.dataset_id == desired_dataset_id && job_details.configuration.load.destination_table.project_id == bigquery.project && job_details.configuration.load.destination_table.table_id == desired_table_id

    if job_details.configuration.load.source_uris.include?(source_url) && job_details.configuration.load.source_format.include?("CSV")
       avail_format = true
   end
  
   

end
end

 tables_data=bigquery.list_table_data(desired_dataset_id, desired_table_id)  || []
if tables_data.total_rows == 4 && tables_data.rows[0].to_json.include?("Arvind") && tables_data.rows[1].to_json.include?("Rohan") && tables_data.rows[2].to_json.include?("Nitish") && tables_data.rows[3].to_json.include?("Aman")
 avail_data = true
end 



# Assessment score and error messages to show user the required steps to get full assessment score
  if avail_state && avail_format && avail_data
    success_message = " Assessment Completed!"
    ret_hash = { :done => true, :score => maximum_score, :message => success_message, :student_message => success_message }
else
    error_message = "Please check desired table is found in Bigquery or not"
    ret_hash[:message] = error_message
    ret_hash[:student_message] = error_message    
  end
  return ret_hash
end